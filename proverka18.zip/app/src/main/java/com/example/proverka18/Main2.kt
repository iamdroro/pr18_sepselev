package com.example.proverka18

class Main2 {
}